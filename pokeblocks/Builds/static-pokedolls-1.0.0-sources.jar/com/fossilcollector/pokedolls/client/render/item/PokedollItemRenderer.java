package com.fossilcollector.pokedolls.client.render.item;

import com.fossilcollector.pokedolls.client.model.PokedollItemModel;
import com.fossilcollector.pokedolls.item.PokedollBlockItem;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class PokedollItemRenderer extends GeoItemRenderer<PokedollBlockItem> {

    public PokedollItemRenderer() {
        super(new PokedollItemModel());
    }

    @Override
    public void method_3166(class_1799 stack, class_811 mode, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        matrices.method_22903();
        
        if (stack.method_7909() instanceof PokedollBlockItem item) {
            float normScale = item.getSpecies().getScaleModifier();
            
            // Center transformations around the item space center (0.5, 0.5, 0.5)
            matrices.method_46416(0.5F, 0.5F, 0.5F);
            
            if (mode == class_811.field_4317) {
                // In GUI/Inventory: rotate 180 degrees around Y so the model faces forward toward the user
                matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                float guiScale = normScale * 0.7F;
                matrices.method_22905(guiScale, guiScale, guiScale);
            } else if (mode == class_811.field_4321 || mode == class_811.field_4322) {
                float handScale = normScale * 0.5F;
                matrices.method_22905(handScale, handScale, handScale);
            } else if (mode == class_811.field_4323 || mode == class_811.field_4320) {
                float handScale = normScale * 0.5F;
                matrices.method_22905(handScale, handScale, handScale);
            } else if (mode == class_811.field_4318) {
                float groundScale = normScale * 0.5F;
                matrices.method_22905(groundScale, groundScale, groundScale);
            } else if (mode == class_811.field_4319) {
                matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                float frameScale = normScale * 0.6F;
                matrices.method_22905(frameScale, frameScale, frameScale);
            } else {
                float defaultScale = normScale * 0.5F;
                matrices.method_22905(defaultScale, defaultScale, defaultScale);
            }
            
            matrices.method_46416(-0.5F, -0.5F, -0.5F);
        }

        super.method_3166(stack, mode, matrices, vertexConsumers, light, overlay);
        
        matrices.method_22909();
    }
}
