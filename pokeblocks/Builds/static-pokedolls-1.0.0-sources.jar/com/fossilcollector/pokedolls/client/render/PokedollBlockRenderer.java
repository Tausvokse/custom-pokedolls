package com.fossilcollector.pokedolls.client.render;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.client.model.PokedollModel;
import com.fossilcollector.pokedolls.entity.PokedollBlockEntity;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class PokedollBlockRenderer extends GeoBlockRenderer<PokedollBlockEntity> {

    public PokedollBlockRenderer(class_5614.class_5615 context) {
        super(new PokedollModel());
    }

    @Override
    public boolean rendersOutsideBoundingBox(PokedollBlockEntity entity) {
        // Globally disable frustum culling for large models
        return true;
    }

    @Override
    public void render(PokedollBlockEntity entity, float partialTick, class_4587 matrixStack, 
                       class_4597 bufferSource, int packedLight, int packedOverlay) {
        if (entity.method_11010().method_11654(PokedollBlock.GLOWING)) {
            packedLight = net.minecraft.class_765.field_32767;
        }
        matrixStack.method_22903();
        
        int rot = entity.method_11010().method_11654(PokedollBlock.ROTATION);
        matrixStack.method_22904(0.5D + entity.getOffsetX(), entity.getOffsetY(), 0.5D + entity.getOffsetZ());
        
        float rotation = entity.hasCustomRotation() ? entity.getCustomRotation() : -(rot * 22.5F);
        if (entity.isAutoRotate()) {
            rotation += (System.currentTimeMillis() % 360000L) * 0.05F;
        }
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
        
        // Normalized base scale * custom scale (or fallback to SIZE multiplier)
        float baseScale = entity.getSpecies().getScaleModifier();
        float sizeMult = entity.getCustomScale() > 0 ? entity.getCustomScale() : entity.method_11010().method_11654(PokedollBlock.SIZE).getScaleMultiplier();
        float scale = baseScale * sizeMult;
        matrixStack.method_22905(scale, scale, scale);
        
        matrixStack.method_22904(-0.5D, 0.0D, -0.5D);

        super.method_3569(entity, partialTick, matrixStack, bufferSource, packedLight, packedOverlay);
        
        matrixStack.method_22909();
    }
}
