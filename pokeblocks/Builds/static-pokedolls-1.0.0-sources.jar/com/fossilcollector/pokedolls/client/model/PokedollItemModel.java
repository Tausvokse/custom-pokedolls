package com.fossilcollector.pokedolls.client.model;

import com.fossilcollector.pokedolls.item.PokedollBlockItem;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class PokedollItemModel extends GeoModel<PokedollBlockItem> {
    @Override
    public class_2960 getModelResource(PokedollBlockItem animatable) {
        return animatable.getSpecies().getGeoModelPath();
    }

    @Override
    public class_2960 getTextureResource(PokedollBlockItem animatable) {
        return animatable.getSpecies().getTexturePath(animatable.isShiny());
    }

    @Override
    public class_2960 getAnimationResource(PokedollBlockItem animatable) {
        return null;
    }
}
