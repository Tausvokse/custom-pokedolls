package com.fossilcollector.pokedolls.client.model;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.entity.PokedollBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class PokedollModel extends GeoModel<PokedollBlockEntity> {
    @Override
    public class_2960 getModelResource(PokedollBlockEntity animatable) {
        return animatable.getSpecies().getGeoModelPath();
    }

    @Override
    public class_2960 getTextureResource(PokedollBlockEntity animatable) {
        boolean isShiny = animatable.method_11010().method_11654(PokedollBlock.SHINY);
        return animatable.getSpecies().getTexturePath(isShiny);
    }

    @Override
    public class_2960 getAnimationResource(PokedollBlockEntity animatable) {
        return class_2960.method_60655("static_pokedolls", "animations/" + animatable.getSpecies().getId() + ".animation.json");
    }
}
