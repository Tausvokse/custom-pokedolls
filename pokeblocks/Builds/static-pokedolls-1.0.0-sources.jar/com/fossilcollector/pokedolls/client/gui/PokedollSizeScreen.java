package com.fossilcollector.pokedolls.client.gui;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.entity.PokedollBlockEntity;
import com.fossilcollector.pokedolls.network.SizeSelectPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;

public class PokedollSizeScreen extends class_437 {
    private final class_2338 pos;
    private float currentScale = 2.0F;
    private float currentRot = 0.0F;
    private float currentOffsetX = 0.0F;
    private float currentOffsetY = 0.0F;
    private float currentOffsetZ = 0.0F;
    private boolean currentGlowing = false;
    private boolean currentAutoRotate = false;
    private String currentPose = "static";

    private CustomSlider scaleSlider;
    private CustomSlider rotSlider;
    private CustomSlider offsetXSlider;
    private CustomSlider offsetYSlider;
    private CustomSlider offsetZSlider;
    private class_4286 glowingCheckbox;
    private class_4286 autoRotateCheckbox;
    private class_4185 poseButton;

    private static final String[] POSES = {"static", "ground_idle", "battle_idle", "ground_walk", "sleep"};
    private static final String[] POSE_LABELS = {
        "Pose: Static (No Anim)",
        "Pose: Idle / Breathing",
        "Pose: Battle Stance",
        "Pose: Walk / Fly",
        "Pose: Sleeping"
    };

    public PokedollSizeScreen(class_2338 pos) {
        super(class_2561.method_43470("Pokedoll Customization Screen"));
        this.pos = pos;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (class_310.method_1551().field_1687 != null && class_310.method_1551().field_1687.method_8321(pos) instanceof PokedollBlockEntity be) {
            this.currentScale = be.getCustomScale() > 0 ? be.getCustomScale() : be.method_11010().method_11654(PokedollBlock.SIZE).getScaleMultiplier();
            this.currentRot = be.hasCustomRotation() ? be.getCustomRotation() : -(be.method_11010().method_11654(PokedollBlock.ROTATION) * 22.5F);
            while (this.currentRot < 0) this.currentRot += 360.0F;
            this.currentRot = this.currentRot % 360.0F;
            this.currentOffsetX = be.getOffsetX();
            this.currentOffsetY = be.getOffsetY();
            this.currentOffsetZ = be.getOffsetZ();
            this.currentGlowing = be.method_11010().method_11654(PokedollBlock.GLOWING);
            this.currentAutoRotate = be.isAutoRotate();
            this.currentPose = be.getPose() != null ? be.getPose() : "static";
        }

        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        int colW = 155;
        int leftX = centerX - colW - 5;
        int rightX = centerX + 5;
        int startY = centerY - 70;

        // Left Column: Sliders
        this.scaleSlider = this.method_37063(new CustomSlider(leftX, startY, colW, 20, "Scale", 0.5, 5.0, this.currentScale, "x"));
        this.rotSlider = this.method_37063(new CustomSlider(leftX, startY + 24, colW, 20, "Rotation", 0.0, 360.0, this.currentRot, "°"));
        this.offsetXSlider = this.method_37063(new CustomSlider(leftX, startY + 48, colW, 20, "Offset X", -1.0, 1.0, this.currentOffsetX, ""));
        this.offsetYSlider = this.method_37063(new CustomSlider(leftX, startY + 72, colW, 20, "Offset Y", -1.0, 1.0, this.currentOffsetY, ""));
        this.offsetZSlider = this.method_37063(new CustomSlider(leftX, startY + 96, colW, 20, "Offset Z", -1.0, 1.0, this.currentOffsetZ, ""));

        // Right Column: Controls
        this.poseButton = this.method_37063(class_4185.method_46430(class_2561.method_43470(getPoseLabel(this.currentPose)), button -> {
            int idx = 0;
            for (int i = 0; i < POSES.length; i++) {
                if (POSES[i].equals(this.currentPose)) { idx = i; break; }
            }
            idx = (idx + 1) % POSES.length;
            this.currentPose = POSES[idx];
            button.method_25355(class_2561.method_43470(getPoseLabel(this.currentPose)));
            sendUpdate();
        }).method_46434(rightX, startY, colW, 20).method_46431());

        this.glowingCheckbox = this.method_37063(class_4286.method_54787(class_2561.method_43470("Glowing Effect"), this.field_22793)
            .method_54789(rightX, startY + 28)
            .method_54794(this.currentGlowing)
            .method_54791((checkbox, checked) -> sendUpdate())
            .method_54788());

        this.autoRotateCheckbox = this.method_37063(class_4286.method_54787(class_2561.method_43470("Auto-Rotate (Showcase)"), this.field_22793)
            .method_54789(rightX, startY + 52)
            .method_54794(this.currentAutoRotate)
            .method_54791((checkbox, checked) -> sendUpdate())
            .method_54788());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Offsets & Rot"), button -> {
            if (this.offsetXSlider != null) this.offsetXSlider.setVal(0.0);
            if (this.offsetYSlider != null) this.offsetYSlider.setVal(0.0);
            if (this.offsetZSlider != null) this.offsetZSlider.setVal(0.0);
            if (this.rotSlider != null) this.rotSlider.setVal(0.0);
            sendUpdate();
        }).method_46434(rightX, startY + 74, colW, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Scale (2.0x Normal)"), button -> {
            if (this.scaleSlider != null) this.scaleSlider.setVal(2.0);
            sendUpdate();
        }).method_46434(rightX, startY + 96, colW, 20).method_46431());

        // Bottom Row: Save & Close
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Save & Close"), button -> {
            sendUpdate();
            this.method_25419();
        }).method_46434(centerX - 100, startY + 124, 200, 20).method_46431());
    }

    private String getPoseLabel(String pose) {
        for (int i = 0; i < POSES.length; i++) {
            if (POSES[i].equals(pose)) return POSE_LABELS[i];
        }
        return "Pose: Static (No Anim)";
    }

    private void sendUpdate() {
        ClientPlayNetworking.send(new SizeSelectPayload(
            this.pos,
            "normal",
            this.glowingCheckbox != null && this.glowingCheckbox.method_20372(),
            this.scaleSlider != null ? (float)this.scaleSlider.getVal() : this.currentScale,
            this.rotSlider != null ? (float)this.rotSlider.getVal() : this.currentRot,
            this.offsetXSlider != null ? (float)this.offsetXSlider.getVal() : this.currentOffsetX,
            this.offsetYSlider != null ? (float)this.offsetYSlider.getVal() : this.currentOffsetY,
            this.offsetZSlider != null ? (float)this.offsetZSlider.getVal() : this.currentOffsetZ,
            this.autoRotateCheckbox != null && this.autoRotateCheckbox.method_20372(),
            this.currentPose
        ));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 90, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private class CustomSlider extends class_357 {
        private final String prefix;
        private final double minVal;
        private final double maxVal;
        private final String suffix;

        public CustomSlider(int x, int y, int width, int height, String prefix, double minVal, double maxVal, double currentVal, String suffix) {
            super(x, y, width, height, class_2561.method_43473(), (class_3532.method_15350(currentVal, minVal, maxVal) - minVal) / (maxVal - minVal));
            this.prefix = prefix;
            this.minVal = minVal;
            this.maxVal = maxVal;
            this.suffix = suffix;
            this.method_25346();
        }

        public double getVal() {
            return this.minVal + this.field_22753 * (this.maxVal - this.minVal);
        }

        public void setVal(double val) {
            this.field_22753 = (class_3532.method_15350(val, this.minVal, this.maxVal) - this.minVal) / (this.maxVal - this.minVal);
            this.method_25346();
        }

        @Override
        protected void method_25346() {
            double val = getVal();
            this.method_25355(class_2561.method_43470(String.format("%s: %.2f%s", this.prefix, val, this.suffix)));
        }

        @Override
        protected void method_25344() {
            sendUpdate();
        }
    }
}
