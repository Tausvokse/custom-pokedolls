package com.fossilcollector.pokedolls.entity;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.registry.ModBlockEntities;
import com.fossilcollector.pokedolls.registry.PokedollSpecies;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class PokedollBlockEntity extends class_2586 implements GeoBlockEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private float customScale = -1.0F;
    private float customRotation = -1.0F;
    private float offsetX = 0.0F;
    private float offsetY = 0.0F;
    private float offsetZ = 0.0F;
    private boolean autoRotate = false;
    private String pose = "static";

    public PokedollBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.POKEDOLL_BLOCK_ENTITY, pos, state);
    }

    public PokedollSpecies getSpecies() {
        if (this.method_11010().method_26204() instanceof PokedollBlock block) {
            return block.getSpecies();
        }
        return PokedollSpecies.TYRANTRUM;
    }

    public float getCustomScale() { return this.customScale; }
    public void setCustomScale(float scale) { this.customScale = scale; }

    public float getCustomRotation() { return this.customRotation; }
    public void setCustomRotation(float rot) { this.customRotation = rot; }
    public boolean hasCustomRotation() { return this.customRotation >= 0.0F; }

    public float getOffsetX() { return this.offsetX; }
    public void setOffsetX(float x) { this.offsetX = x; }

    public float getOffsetY() { return this.offsetY; }
    public void setOffsetY(float y) { this.offsetY = y; }

    public float getOffsetZ() { return this.offsetZ; }
    public void setOffsetZ(float z) { this.offsetZ = z; }

    public boolean isAutoRotate() { return this.autoRotate; }
    public void setAutoRotate(boolean autoRotate) { this.autoRotate = autoRotate; }

    public String getPose() { return this.pose; }
    public void setPose(String pose) { this.pose = pose; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 5, state -> {
            String currentPose = this.getPose();
            if (currentPose == null || currentPose.isEmpty() || currentPose.equals("static")) {
                return PlayState.STOP;
            }
            String speciesId = this.getSpecies().getId();
            String target = speciesId.equals("tyrunt_pokedoll") ? "tyrunt" : speciesId;
            String animName = "animation." + target + "." + currentPose;
            
            if (currentPose.equals("battle_idle")) {
                if (speciesId.equals("mew") || speciesId.equals("mewtwo")) animName = "animation." + target + ".pose";
                else if (speciesId.equals("arctovish") || speciesId.equals("cradily") || speciesId.equals("kabuto") || speciesId.equals("lileep") || speciesId.equals("tirtouga")) animName = "animation." + target + ".ground_idle";
            } else if (currentPose.equals("sleep")) {
                if (speciesId.equals("mew") || speciesId.equals("mewtwo") || speciesId.equals("tyrantrum")) animName = "animation." + target + ".ground_idle";
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop(animName));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        nbt.method_10548("CustomScale", this.customScale);
        nbt.method_10548("CustomRotation", this.customRotation);
        nbt.method_10548("OffsetX", this.offsetX);
        nbt.method_10548("OffsetY", this.offsetY);
        nbt.method_10548("OffsetZ", this.offsetZ);
        nbt.method_10556("AutoRotate", this.autoRotate);
        if (this.pose != null) {
            nbt.method_10582("Pose", this.pose);
        }
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11014(nbt, registryLookup);
        if (nbt.method_10545("CustomScale")) this.customScale = nbt.method_10583("CustomScale");
        if (nbt.method_10545("CustomRotation")) this.customRotation = nbt.method_10583("CustomRotation");
        if (nbt.method_10545("OffsetX")) this.offsetX = nbt.method_10583("OffsetX");
        if (nbt.method_10545("OffsetY")) this.offsetY = nbt.method_10583("OffsetY");
        if (nbt.method_10545("OffsetZ")) this.offsetZ = nbt.method_10583("OffsetZ");
        if (nbt.method_10545("AutoRotate")) this.autoRotate = nbt.method_10577("AutoRotate");
        if (nbt.method_10545("Pose")) this.pose = nbt.method_10558("Pose");
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
