package com.fossilcollector.pokedolls.registry;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.entity.PokedollBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {
    public static class_2591<PokedollBlockEntity> POKEDOLL_BLOCK_ENTITY;

    public static void registerAll() {
        POKEDOLL_BLOCK_ENTITY = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655(ModBlocks.MOD_ID, "pokedoll_block_entity"),
            FabricBlockEntityTypeBuilder.create(
                PokedollBlockEntity::new,
                ModBlocks.BLOCKS.values().toArray(new PokedollBlock[0])
            ).build()
        );
    }
}
