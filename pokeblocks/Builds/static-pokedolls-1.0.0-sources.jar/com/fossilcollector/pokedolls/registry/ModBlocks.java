package com.fossilcollector.pokedolls.registry;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.item.PokedollBlockItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import java.util.EnumMap;
import java.util.Map;

public class ModBlocks {
    public static final String MOD_ID = "static_pokedolls";
    
    public static final Map<PokedollSpecies, PokedollBlock> BLOCKS = new EnumMap<>(PokedollSpecies.class);
    public static final Map<PokedollSpecies, PokedollBlockItem> NORMAL_ITEMS = new EnumMap<>(PokedollSpecies.class);
    public static final Map<PokedollSpecies, PokedollBlockItem> SHINY_ITEMS = new EnumMap<>(PokedollSpecies.class);
    
    public static class_1792 POKEDOLL_CHISEL;
    public static class_1761 POKEDOLLS_GROUP;

    public static void registerAll() {
        POKEDOLL_CHISEL = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pokedoll_chisel"), new class_1792(new class_1792.class_1793().method_7889(1)));

        for (PokedollSpecies species : PokedollSpecies.values()) {
            class_2960 blockId = class_2960.method_60655(MOD_ID, species.getId() + "_doll");
            class_2960 shinyItemId = class_2960.method_60655(MOD_ID, species.getId() + "_shiny_doll");

            PokedollBlock block = new PokedollBlock(class_4970.class_2251.method_9637().method_22488().method_9629(1.5f, 6.0f).method_9631(state -> state.method_11654(PokedollBlock.GLOWING) ? 15 : 0), species);
            PokedollBlockItem normalItem = new PokedollBlockItem(block, new class_1792.class_1793(), species, false);
            PokedollBlockItem shinyItem = new PokedollBlockItem(block, new class_1792.class_1793(), species, true);

            class_2378.method_10230(class_7923.field_41175, blockId, block);
            class_2378.method_10230(class_7923.field_41178, blockId, normalItem);
            class_2378.method_10230(class_7923.field_41178, shinyItemId, shinyItem);

            BLOCKS.put(species, block);
            NORMAL_ITEMS.put(species, normalItem);
            SHINY_ITEMS.put(species, shinyItem);
        }

        POKEDOLLS_GROUP = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(NORMAL_ITEMS.get(PokedollSpecies.TYRANTRUM)))
            .method_47321(class_2561.method_43471("itemGroup.static_pokedolls.general"))
            .method_47317((context, entries) -> {
                entries.method_45421(POKEDOLL_CHISEL);
                NORMAL_ITEMS.values().forEach(entries::method_45421);
                SHINY_ITEMS.values().forEach(entries::method_45421);
            })
            .method_47324();

        class_2378.method_10230(class_7923.field_44687, class_2960.method_60655(MOD_ID, "general"), POKEDOLLS_GROUP);
    }
}
