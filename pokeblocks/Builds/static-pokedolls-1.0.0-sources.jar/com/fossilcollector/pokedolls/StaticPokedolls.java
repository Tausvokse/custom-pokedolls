package com.fossilcollector.pokedolls;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.block.PokedollSize;
import com.fossilcollector.pokedolls.entity.PokedollBlockEntity;
import com.fossilcollector.pokedolls.network.SizeSelectPayload;
import com.fossilcollector.pokedolls.registry.ModBlockEntities;
import com.fossilcollector.pokedolls.registry.ModBlocks;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StaticPokedolls implements ModInitializer {
    public static final String MOD_ID = "static_pokedolls";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Static Pokedolls for Cobblemon (Fabric 1.21.1)...");
        ModBlocks.registerAll();
        ModBlockEntities.registerAll();

        PayloadTypeRegistry.playC2S().register(SizeSelectPayload.ID, SizeSelectPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SizeSelectPayload.ID, (payload, context) -> {
            context.player().field_13995.execute(() -> {
                class_2338 pos = payload.pos();
                String sizeName = payload.sizeName();
                if (context.player().method_5707(pos.method_46558()) < 256.0) {
                    class_1937 world = context.player().method_37908();
                    class_2680 state = world.method_8320(pos);
                    if (state.method_26204() instanceof PokedollBlock) {
                        for (PokedollSize size : PokedollSize.values()) {
                            if (size.method_15434().equals(sizeName)) {
                                class_2680 newState = state.method_11657(PokedollBlock.SIZE, size).method_11657(PokedollBlock.GLOWING, payload.glowing());
                                if (state != newState) {
                                    world.method_8652(pos, newState, class_2248.field_31036);
                                }
                                break;
                            }
                        }
                        if (world.method_8321(pos) instanceof PokedollBlockEntity be) {
                            be.setCustomScale(payload.scale());
                            be.setCustomRotation(payload.rotationAngle());
                            be.setOffsetX(payload.offsetX());
                            be.setOffsetY(payload.offsetY());
                            be.setOffsetZ(payload.offsetZ());
                            be.setAutoRotate(payload.autoRotate());
                            be.setPose(payload.pose());
                            be.method_5431();
                            world.method_8413(pos, state, world.method_8320(pos), class_2248.field_31036);
                        }
                    }
                }
            });
        });

        LOGGER.info("Successfully registered 27 Pokedoll species (54 variants), BlockEntities, and Size Networking!");
    }
}
