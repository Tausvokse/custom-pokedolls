package com.fossilcollector.pokedolls.network;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SizeSelectPayload(
    class_2338 pos,
    String sizeName,
    boolean glowing,
    float scale,
    float rotationAngle,
    float offsetX,
    float offsetY,
    float offsetZ,
    boolean autoRotate,
    String pose
) implements class_8710 {
    public static final class_8710.class_9154<SizeSelectPayload> ID = new class_8710.class_9154<>(class_2960.method_60655("static_pokedolls", "size_select"));
    
    public static final class_9139<class_9129, SizeSelectPayload> CODEC = class_9139.method_56438(
        (payload, buf) -> {
            buf.method_10807(payload.pos());
            buf.method_10814(payload.sizeName());
            buf.method_52964(payload.glowing());
            buf.method_52941(payload.scale());
            buf.method_52941(payload.rotationAngle());
            buf.method_52941(payload.offsetX());
            buf.method_52941(payload.offsetY());
            buf.method_52941(payload.offsetZ());
            buf.method_52964(payload.autoRotate());
            buf.method_10814(payload.pose());
        },
        buf -> new SizeSelectPayload(
            buf.method_10811(),
            buf.method_19772(),
            buf.readBoolean(),
            buf.readFloat(),
            buf.readFloat(),
            buf.readFloat(),
            buf.readFloat(),
            buf.readFloat(),
            buf.readBoolean(),
            buf.method_19772()
        )
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
