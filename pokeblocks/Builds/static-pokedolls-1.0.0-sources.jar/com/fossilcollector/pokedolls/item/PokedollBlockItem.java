package com.fossilcollector.pokedolls.item;

import com.fossilcollector.pokedolls.block.PokedollBlock;
import com.fossilcollector.pokedolls.client.render.item.PokedollItemRenderer;
import com.fossilcollector.pokedolls.registry.PokedollSpecies;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_756;

public class PokedollBlockItem extends class_1747 implements GeoItem {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final boolean isShiny;
    private final PokedollSpecies species;

    public PokedollBlockItem(class_2248 block, class_1793 settings, PokedollSpecies species, boolean isShiny) {
        super(block, settings);
        this.species = species;
        this.isShiny = isShiny;
    }

    public PokedollSpecies getSpecies() {
        return this.species;
    }

    public boolean isShiny() {
        return this.isShiny;
    }

    @Override
    public String method_7876() {
        if (this.isShiny) {
            return "item.static_pokedolls." + this.species.getId() + "_shiny_doll";
        }
        return super.method_7876();
    }

    @Override
    protected class_2680 method_7707(class_1750 context) {
        class_2680 state = super.method_7707(context);
        return state != null ? state.method_11657(PokedollBlock.SHINY, this.isShiny) : null;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Static items
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(new GeoRenderProvider() {
            private PokedollItemRenderer renderer;

            @Override
            public class_756 getGeoItemRenderer() {
                if (this.renderer == null) {
                    this.renderer = new PokedollItemRenderer();
                }
                return this.renderer;
            }
        });
    }
}
