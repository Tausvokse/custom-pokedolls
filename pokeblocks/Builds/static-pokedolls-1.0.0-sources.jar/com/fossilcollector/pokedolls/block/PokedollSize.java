package com.fossilcollector.pokedolls.block;

import net.minecraft.class_3542;

public enum PokedollSize implements class_3542 {
    SMALL("small", 0.75F),
    DOLL("doll", 1.0F),
    NORMAL("normal", 2.0F),
    GIANT("giant", 3.5F),
    ENORMOUS("enormous", 5.0F);

    private final String name;
    private final float scaleMultiplier;

    PokedollSize(String name, float scaleMultiplier) {
        this.name = name;
        this.scaleMultiplier = scaleMultiplier;
    }

    @Override
    public String method_15434() {
        return this.name;
    }

    public float getScaleMultiplier() {
        return this.scaleMultiplier;
    }
}
