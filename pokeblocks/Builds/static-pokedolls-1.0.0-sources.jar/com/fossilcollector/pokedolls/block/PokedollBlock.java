package com.fossilcollector.pokedolls.block;

import com.fossilcollector.pokedolls.entity.PokedollBlockEntity;
import com.fossilcollector.pokedolls.registry.PokedollSpecies;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3532;
import net.minecraft.class_3542;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public class PokedollBlock extends class_2237 implements class_3737 {
    public static final class_2758 ROTATION = class_2741.field_12532;
    public static final class_2746 SHINY = class_2746.method_11825("shiny");
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    public static final class_2746 GLOWING = class_2746.method_11825("glowing");
    public static final class_2754<PokedollSize> SIZE = class_2754.method_11850("size", PokedollSize.class);

    public static java.util.function.Consumer<class_2338> SCREEN_OPENER = pos -> {};

    public static final MapCodec<PokedollBlock> CODEC = RecordCodecBuilder.mapCodec(instance ->
        instance.group(
            method_54096(),
            class_3542.method_28140(PokedollSpecies::values).fieldOf("species").forGetter(PokedollBlock::getSpecies)
        ).apply(instance, PokedollBlock::new)
    );

    private final PokedollSpecies species;

    public PokedollBlock(class_2251 settings, PokedollSpecies species) {
        super(settings);
        this.species = species;
        this.method_9590(this.field_10647.method_11664()
            .method_11657(ROTATION, 0)
            .method_11657(SHINY, false)
            .method_11657(WATERLOGGED, false)
            .method_11657(SIZE, PokedollSize.NORMAL)
            .method_11657(GLOWING, false));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    public PokedollSpecies getSpecies() {
        return this.species;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION, SHINY, WATERLOGGED, SIZE, GLOWING);
    }

    public static final class_265 BASE_SHAPE = class_2248.method_9541(2, 0, 2, 14, 16, 14);

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_3610 fluidState = ctx.method_8045().method_8316(ctx.method_8037());
        int rot = class_3532.method_15357((double)((ctx.method_8044()) * 16.0F / 360.0F) + 0.5D) & 15;
        boolean isShiny = ctx.method_8041().method_7909().toString().contains("shiny");
        return this.method_9564()
            .method_11657(ROTATION, rot)
            .method_11657(SHINY, isShiny)
            .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910)
            .method_11657(SIZE, PokedollSize.NORMAL)
            .method_11657(GLOWING, false);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (world.method_8608() && placer != null && placer.method_31747()) {
            SCREEN_OPENER.accept(pos);
        }
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PokedollBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return BASE_SHAPE;
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return BASE_SHAPE;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        return class_1269.field_5811;
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (hand == class_1268.field_5808 && stack.method_31574(com.fossilcollector.pokedolls.registry.ModBlocks.POKEDOLL_CHISEL)) {
            if (world.method_8608()) {
                SCREEN_OPENER.accept(pos);
            }
            return class_9062.field_47728;
        }
        return class_9062.field_47731;
    }
}
